'use strict';
//declare variables
let randomNumber = Math.floor(Math.random()*20) + 1;
const message = document.querySelector(".message");
const score = document.querySelector(".score");
const number = document.querySelector(".number");
const highScore = document.querySelector(".highscore");
const body = document.querySelector("body");

//check button functions
document.querySelector(".check").addEventListener("click", function(){

    const userInput = Number(document.querySelector(".guess").value);
    if (typeof userInput === NaN || userInput === 0){
        message.textContent = "⛔ No Number";
    }
    else{
        if (userInput < randomNumber){
            message.textContent = "📉 Too low";
            score.textContent -= 1;
        }
        else if (userInput > randomNumber){
            message.textContent = "📈 Too high";
            score.textContent -= 1;
        }
        else{
            message.textContent = "🎉 Correct Number";
            number.textContent = randomNumber;
            body.style.backgroundColor = "#60b347";
            body.style.boxShadow = "0 0 10px #555";
            if (Number(highScore.textContent) < Number(score.textContent)){
                highScore.textContent = score.textContent;
            }
            document.querySelector(".guess").disabled = true;
            document.querySelector(".check").disabled = true;
            number.style.width = "30rem";

        }
        if (Number(score.textContent) === 0){
            message.textContent = "💥You have lost the game!!!";
            body.style.backgroundColor = "red";
            number.textContent = randomNumber;
            document.querySelector(".guess").disabled = true;
            document.querySelector(".check").disabled = true;
            number.style.width = "30rem";
        }
    }
});
//again button function
document.querySelector(".again").addEventListener("click",function(){
     randomNumber = Math.floor(Math.random() * 20) + 1;
    message.textContent = "start guessing...";
    number.textContent = "?";
    number.style.width = "15rem";
    document.querySelector(".guess").value = "";
    body.style.backgroundColor = "#222";
    document.querySelector(".guess").disabled = false;
    document.querySelector(".check").disabled = false;
    score.textContent = 20;

});


